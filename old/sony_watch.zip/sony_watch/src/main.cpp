#include <iostream>
#include <string>
#include <vector>
#include <unordered_set>
#include <unordered_map>
#include <cstdint>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <mutex>
#include <condition_variable>
#include <atomic>
#include <csignal>
#include <chrono>

// Sony Camera Remote SDK headers
#include "CRSDK/CameraRemote_SDK.h"
#include "CRSDK/ICrCameraObjectInfo.h"
#include "CRSDK/IDeviceCallback.h"

namespace SDK = SCRSDK;

// ---- graceful shutdown flag ----
static std::atomic<bool> g_stop{false};

static void signal_handler(int signo) { (void)signo; g_stop.store(true, std::memory_order_relaxed); }
static void install_signal_handlers() {
    struct sigaction sa{}; sa.sa_handler = signal_handler; sigemptyset(&sa.sa_mask); sa.sa_flags = 0;
    sigaction(SIGINT, &sa, nullptr); sigaction(SIGTERM, &sa, nullptr);
#ifdef SIGHUP
    sigaction(SIGHUP, &sa, nullptr);
#endif
#ifdef SIGPIPE
    struct sigaction ign{}; ign.sa_handler = SIG_IGN; sigemptyset(&ign.sa_mask); ign.sa_flags = 0;
    sigaction(SIGPIPE, &ign, nullptr);
#endif
}

static CrInt32u ip_to_uint32(const std::string& ip) {
    unsigned int a=0,b=0,c=0,d=0;
    if (std::sscanf(ip.c_str(), "%u.%u.%u.%u", &a,&b,&c,&d) != 4) return 0;
    return (CrInt32u)( (a) | (b<<8) | (c<<16) | (d<<24) );
}

static bool parse_mac(const std::string& macStr, unsigned char out[6]) {
    int vals[6];
    if (std::sscanf(macStr.c_str(), "%x:%x:%x:%x:%x:%x",
                    &vals[0],&vals[1],&vals[2],&vals[3],&vals[4],&vals[5]) == 6) {
        for (int i=0;i<6;++i) out[i] = static_cast<unsigned char>(vals[i] & 0xFF);
        return true;
    }
    return false;
}

// ---- Quiet, focused device callback ----
class QuietCallback : public SDK::IDeviceCallback {
public:
    std::mutex mtx;
    std::condition_variable cv;
    bool contents_changed = false;
    bool verbose = false; // set by CLI

    // de-dup spammy warn/error codes
    CrInt32u last_warning = 0;
    CrInt32u last_error = 0;

    void OnConnected(SDK::DeviceConnectionVersioin v) override {
        if (verbose) std::cout << "[CB] OnConnected: version=" << v << std::endl;
    }
    void OnDisconnected(CrInt32u error) override {
        std::cout << "[CB] OnDisconnected: error=0x" << std::hex << error << std::dec << std::endl;
    }
    void OnWarning(CrInt32u warning) override {
        if (warning != last_warning) {
            std::cout << "[CB] OnWarning: 0x" << std::hex << warning << std::dec << std::endl;
            last_warning = warning;
        }
    }
    void OnError(CrInt32u error) override {
        if (error != last_error) {
            std::cout << "[CB] OnError: 0x" << std::hex << error << std::dec << std::endl;
            last_error = error;
        }
    }
    void OnPropertyChanged() override {
        if (verbose) std::cout << "[CB] OnPropertyChanged()" << std::endl;
    }
    void OnLvPropertyChanged() override {
        if (verbose) std::cout << "[CB] OnLvPropertyChanged()" << std::endl;
    }
    void OnNotifyRemoteTransferContentsListChanged(CrInt32u notify, CrInt32u slotNumber, CrInt32u addSize) override {
        std::cout << "[CB] ContentsListChanged: notify=0x" << std::hex << notify << std::dec
                  << " slot=" << slotNumber << " add=" << addSize << std::endl;
        std::lock_guard<std::mutex> lk(mtx);
        contents_changed = true;
        cv.notify_all();
    }
    void OnNotifyContentsTransfer(CrInt32u notify, SDK::CrContentHandle contentHandle, CrChar* filename) override {
        if (verbose) {
            const char* file = filename ? filename : "(null)";
            std::cout << "[CB] ContentsTransfer: notify=0x" << std::hex << notify << std::dec
                      << " handle=0x" << std::hex << contentHandle << std::dec
                      << " file=" << file << std::endl;
        }
    }
    void OnNotifyRemoteTransferResult(CrInt32u notify, CrInt32u per, CrInt8u* /*data*/, CrInt64u size) override {
        if (verbose) {
            std::cout << "[CB] RemoteTransferResult: notify=0x" << std::hex << notify << std::dec
                      << " per=" << per << " size=" << size << std::endl;
        }
    }
    void OnNotifyFTPTransferResult(CrInt32u notify, CrInt32u numOfSuccess, CrInt32u numOfFail) override {
        if (verbose) {
            std::cout << "[CB] FTPTransferResult: notify=0x" << std::hex << notify << std::dec
                      << " success=" << numOfSuccess << " fail=" << numOfFail << std::endl;
        }
    }
    void OnNotifyRemoteFirmwareUpdateResult(CrInt32u notify, const void* param) override {
        if (verbose) {
            std::cout << "[CB] FWUpdateResult: notify=0x" << std::hex << notify << std::dec
                      << " param=" << param << std::endl;
        }
    }
    void OnReceivePlaybackTimeCode(CrInt32u timeCode) override {
        if (verbose) std::cout << "[CB] PlaybackTimeCode: " << timeCode << std::endl;
    }
    void OnNotifyMonitorUpdated(CrInt32u type, CrInt32u frameNo) override {
        if (verbose) {
            std::cout << "[CB] MonitorUpdated: type=0x" << std::hex << type << std::dec
                      << " frameNo=" << frameNo << std::endl;
        }
    }
};

// Utility: print new files when detected (uses folder handle + filename)
static void scan_and_report_new(SDK::CrDeviceHandle handle,
                                std::unordered_set<SDK::CrContentHandle>& seen) {
    SDK::CrMtpFolderInfo* folders = nullptr;
    CrInt32u numFolders = 0;
    if (SDK::GetDateFolderList(handle, &folders, &numFolders) != SDK::CrError_None || !folders) return;
    for (CrInt32u i = 0; i < numFolders; ++i) {
        SDK::CrContentHandle* contents = nullptr;
        CrInt32u numContents = 0;
        if (SDK::GetContentsHandleList(handle, folders[i].handle, &contents, &numContents) == SDK::CrError_None && contents) {
            for (CrInt32u j = 0; j < numContents; ++j) {
                auto h = contents[j];
                if (seen.find(h) == seen.end()) {
                    SDK::CrMtpContentsInfo info{};
                    if (SDK::GetContentsDetailInfo(handle, h, &info) == SDK::CrError_None) {
                        const char* fname = info.fileName ? info.fileName : "unknown";
                        std::cout << "[NEW] folder#" << (unsigned)folders[i].handle << "/" << fname << std::endl;
                    } else {
                        std::cout << "[NEW] handle=0x" << std::hex << h << std::dec << std::endl;
                    }
                    seen.insert(h);
                }
            }
            SDK::ReleaseContentsHandleList(handle, contents);
        }
    }
    SDK::ReleaseDateFolderList(handle, folders);
}

int main(int argc, char** argv) {
    install_signal_handlers();

    std::string explicit_ip;
    std::string explicit_mac;
    bool verbose = false;

    // Simple CLI parsing
    for (int i=1;i<argc;i++) {
        std::string a = argv[i];
        if (a == "--ip" && i+1<argc) { explicit_ip = argv[++i]; }
        else if (a == "--mac" && i+1<argc) { explicit_mac = argv[++i]; }
        else if (a == "--verbose" || a == "-v") { verbose = true; }
    }

    std::cout << "[watch-quiet] Init SDK..." << std::endl;
    if (!SDK::Init()) { std::cerr << "Init failed\n"; return 1; }

    QuietCallback callback;
    callback.verbose = verbose;

    SDK::CrError err = SDK::CrError_None;
    const SDK::ICrCameraObjectInfo* selected = nullptr;
    SDK::ICrEnumCameraObjectInfo* enum_list = nullptr;
    SDK::ICrCameraObjectInfo* created = nullptr;
    SDK::CrDeviceHandle handle = 0;

    auto cleanup = [&](){
        std::cout << "[watch-quiet] Cleaning up..." << std::endl;
        if (handle) {
            SDK::Disconnect(handle);
            SDK::ReleaseDevice(handle);
            handle = 0;
        }
        if (created) { created->Release(); created = nullptr; }
        if (enum_list) { enum_list->Release(); enum_list = nullptr; }
        SDK::Release();
        std::cout << "[watch-quiet] Cleanup done." << std::endl;
    };

    // enumerate or build by IP
    if (explicit_ip.empty()) {
        if (verbose) std::cout << "[watch-quiet] Enumerating..." << std::endl;
        err = SDK::EnumCameraObjects(&enum_list, 3);
        if (err == SDK::CrError_None && enum_list) {
            auto count = enum_list->GetCount();
            for (CrInt32u i = 0; i < count; ++i) {
                auto info = enum_list->GetCameraObjectInfo(i);
                if (!info) continue;
                const char* connType = info->GetConnectionTypeName();
                if (connType && std::string(connType) == "IP") { selected = info; break; }
                if (!selected) selected = info;
            }
        } else if (verbose) {
            std::cout << "[watch-quiet] EnumCameraObjects failed: 0x" << std::hex << err << std::dec << std::endl;
        }
    }

    if (!selected) {
        std::string ip = explicit_ip.empty() ? std::string("192.168.10.184") : explicit_ip;
        CrInt32u ipAddr = ip_to_uint32(ip);
        if (ipAddr == 0) { std::cerr << "Bad IP\n"; cleanup(); return 2; }
        unsigned char mac[6] = {0,0,0,0,0,0};
        if (!explicit_mac.empty() && !parse_mac(explicit_mac, mac)) {
            std::cerr << "WARN: bad MAC, ignoring: " << explicit_mac << std::endl;
        }
        SDK::CrCameraDeviceModelList model = SDK::CrCameraDeviceModel_ILCE_6700;
        err = SDK::CreateCameraObjectInfoEthernetConnection(&created, model, ipAddr, mac, 0);
        if (err != SDK::CrError_None || !created) { std::cerr << "CreateCameraObjectInfoEthernetConnection failed\n"; cleanup(); return 3; }
        selected = created;
    }

    // Optional fingerprint
    char fpBuff[256] = {0}; CrInt32u fpLen = 0;
    SDK::GetFingerprint(const_cast<SDK::ICrCameraObjectInfo*>(selected), fpBuff, &fpLen);

    // Connect
    if (verbose) std::cout << "[watch-quiet] Connecting..." << std::endl;
    err = SDK::Connect(const_cast<SDK::ICrCameraObjectInfo*>(selected), &callback, &handle,
                       SDK::CrSdkControlMode_Remote, SDK::CrReconnecting_ON,
                       nullptr, nullptr, (fpLen>0?fpBuff:nullptr), fpLen);
    if (err != SDK::CrError_None || handle == 0) {
        std::cerr << "Connect failed: 0x" << std::hex << err << std::dec << "\n";
        cleanup();
        return 4;
    }
    std::cout << "[watch-quiet] Connected. Press Ctrl+C to stop." << std::endl;

    // Index existing
    std::unordered_set<SDK::CrContentHandle> seen;
    {
        SDK::CrMtpFolderInfo* folders = nullptr;
        CrInt32u numFolders = 0;
        if (SDK::GetDateFolderList(handle, &folders, &numFolders) == SDK::CrError_None && folders) {
            for (CrInt32u i = 0; i < numFolders; ++i) {
                SDK::CrContentHandle* contents = nullptr;
                CrInt32u numContents = 0;
                if (SDK::GetContentsHandleList(handle, folders[i].handle, &contents, &numContents) == SDK::CrError_None && contents) {
                    for (CrInt32u j = 0; j < numContents; ++j) seen.insert(contents[j]);
                    SDK::ReleaseContentsHandleList(handle, contents);
                }
            }
            SDK::ReleaseDateFolderList(handle, folders);
        }
    }

    // Event-driven wait with periodic wake (so signals end the loop promptly)
    while (!g_stop.load(std::memory_order_relaxed)) {
        std::unique_lock<std::mutex> lk(callback.mtx);
        callback.cv.wait_for(lk, std::chrono::milliseconds(500), [&]{ return callback.contents_changed || g_stop.load(); });
        if (g_stop.load()) break;
        bool changed = callback.contents_changed;
        callback.contents_changed = false;
        lk.unlock();

        if (changed) {
            std::cout << "[watch-quiet] Contents list changed: rescanning..." << std::endl;
            scan_and_report_new(handle, seen);
        }
    }

    std::cout << "[watch-quiet] Stop requested. Disconnecting..." << std::endl;
    cleanup();
    return 0;
}
