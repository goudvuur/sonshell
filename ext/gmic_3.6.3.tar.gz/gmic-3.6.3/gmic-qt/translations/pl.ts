<?xml version="1.0" encoding="utf-8"?>

<!-- Original Polish translation done by Alex Mozheiko -->

<!DOCTYPE TS>
<TS version="2.1" language="pl">
<context>
    <name>DialogSettings</name>
    <message>
        <location filename="../ui/dialogsettings.ui" line="14"/>
        <source>Dialog</source>
        <translation>Okno dialogowe</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="250"/>
        <source>Internet updates</source>
        <translation>Aktualizacje z Internetu</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="259"/>
        <source>Update now</source>
        <translation>Uaktualnij teraz</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="30"/>
        <source>Layout</source>
        <translation>Układ</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="24"/>
        <source>Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="64"/>
        <source>Preview on the &amp;left</source>
        <translation>Podgląd &amp;po lewej stronie</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="94"/>
        <source>Pre&amp;view on right side</source>
        <translation>Podgląd &amp;po prawej stronie</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="113"/>
        <source>Theme</source>
        <translation>Wygląd</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="119"/>
        <source>&amp;Default</source>
        <translation>&amp;Domyślnie</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="126"/>
        <source>Dar&amp;k</source>
        <translation>&amp;Ciemny</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="139"/>
        <source>&lt;i&gt;(Restart needed)&lt;/I&gt;</source>
        <translation>&lt;i&gt;(Wymaga zrestartowania)&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="149"/>
        <source>Language</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="179"/>
        <source>Always enable preview zooming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="186"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-style:italic;&quot;&gt;(Warning: preview may be inaccurate&lt;br/&gt;if checked.)&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="196"/>
        <source>Misc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="209"/>
        <source>Use native file dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="216"/>
        <source>&amp;Enable High-DPI support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="223"/>
        <source>&lt;i&gt;(Restart needed)&lt;/i&gt;</source>
        <translation type="unfinished">&lt;i&gt;(Wymaga zrestartowania)&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="239"/>
        <source>Filter sources</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="244"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="282"/>
        <source>Output messages</source>
        <translation>Komunikat wyjścia</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="202"/>
        <source>&amp;Use native color dialog</source>
        <translation>&amp;Użyć kolorów systemowych</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="163"/>
        <source>Preview</source>
        <translation>Podgląd</translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="169"/>
        <source>Timeout (seconds)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="36"/>
        <source>Show institution logos</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="291"/>
        <source>Notify when scheduled update fails</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/dialogsettings.ui" line="333"/>
        <source>&amp;Ok</source>
        <translation>&amp;Ok</translation>
    </message>
</context>
<context>
    <name>FiltersView</name>
    <message>
        <location filename="../ui/filtersview.ui" line="14"/>
        <source>Form</source>
        <translation>GMIC</translation>
    </message>
</context>
<context>
    <name>GmicQt::ColorParameter</name>
    <message>
        <location filename="../src/FilterParameters/ColorParameter.cpp" line="213"/>
        <source>Select color</source>
        <translation>Wybór koloru</translation>
    </message>
</context>
<context>
    <name>GmicQt::DialogSettings</name>
    <message>
        <location filename="../src/DialogSettings.cpp" line="45"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="51"/>
        <source>Never</source>
        <translation>Nigdy</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="52"/>
        <source>Daily</source>
        <translation>Codziennie</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="53"/>
        <source>Weekly</source>
        <translation>Cotygodniowo</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="54"/>
        <source>Every 2 weeks</source>
        <translation>Co 2 tygodnie</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="55"/>
        <source>Monthly</source>
        <translation>Miesięcznie</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="57"/>
        <source>At launch (debug)</source>
        <translation>Przy starcie (debugowanie)</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="65"/>
        <source>Output messages</source>
        <translation>Komunikat wyjścia</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="66"/>
        <source>Quiet (default)</source>
        <translation>Brak (domyślnie)</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="67"/>
        <source>Verbose (console)</source>
        <translation>Ogólny (konsola)</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="68"/>
        <source>Verbose (log file)</source>
        <translation>Ogólny (plik log)</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="69"/>
        <source>Very verbose (console)</source>
        <translation>Dokładny (konsola)</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="70"/>
        <source>Very verbose (log file)</source>
        <translation>Dokładny (plik log)</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="71"/>
        <source>Debug (console)</source>
        <translation>Debugowanie (konsola)</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="72"/>
        <source>Debug (log file)</source>
        <translation>Debugowanie (plik log)</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="88"/>
        <source>Check to use Native/OS color dialog, uncheck to use Qt&apos;s</source>
        <translation>Zaznacz aby używać natywny/systemowy zestaw kolorów, wyłącz dla QT</translation>
    </message>
    <message>
        <location filename="../src/DialogSettings.cpp" line="90"/>
        <source>Check to use Native/OS file dialog, uncheck to use Qt&apos;s</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GmicQt::FileParameter</name>
    <message>
        <location filename="../src/FilterParameters/FileParameter.cpp" line="159"/>
        <location filename="../src/FilterParameters/FileParameter.cpp" line="162"/>
        <location filename="../src/FilterParameters/FileParameter.cpp" line="165"/>
        <source>Select a file</source>
        <translation>Wybierz plik</translation>
    </message>
</context>
<context>
    <name>GmicQt::FilterParametersWidget</name>
    <message>
        <location filename="../src/FilterParameters/FilterParametersWidget.cpp" line="44"/>
        <location filename="../src/FilterParameters/FilterParametersWidget.cpp" line="273"/>
        <source>&lt;i&gt;Select a filter&lt;/i&gt;</source>
        <translation>&lt;i&gt;Wybierz filtr&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../src/FilterParameters/FilterParametersWidget.cpp" line="240"/>
        <source>&lt;i&gt;No parameters&lt;/i&gt;</source>
        <translation>&lt;i&gt;Brak parametrów&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../src/FilterParameters/FilterParametersWidget.cpp" line="245"/>
        <source>Error parsing filter parameters

</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GmicQt::FiltersPresenter</name>
    <message>
        <location filename="../src/FilterSelector/FiltersPresenter.cpp" line="513"/>
        <source>Unknown filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterSelector/FiltersPresenter.cpp" line="623"/>
        <source>Cannot find this fave&apos;s original filter
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GmicQt::FiltersView</name>
    <message>
        <location filename="../src/FilterSelector/FiltersView/FiltersView.cpp" line="353"/>
        <source>Remove fave</source>
        <translation>Usuń z ulubionych</translation>
    </message>
    <message>
        <location filename="../src/FilterSelector/FiltersView/FiltersView.cpp" line="680"/>
        <source>Rename Fave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterSelector/FiltersView/FiltersView.cpp" line="682"/>
        <source>Remove Fave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterSelector/FiltersView/FiltersView.cpp" line="684"/>
        <source>Clone Fave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterSelector/FiltersView/FiltersView.cpp" line="688"/>
        <source>Add Fave</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterSelector/FiltersView/FiltersView.cpp" line="707"/>
        <source>Remove All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterSelector/FiltersView/FiltersView.cpp" line="714"/>
        <source>%1 (%2 %3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterSelector/FiltersView/FiltersView.cpp" line="714"/>
        <source>Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterSelector/FiltersView/FiltersView.cpp" line="714"/>
        <source>Filter</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterSelector/FiltersView/FiltersView.cpp" line="354"/>
        <source>Do you really want to remove the following fave?

%1
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GmicQt::FolderParameter</name>
    <message>
        <location filename="../src/FilterParameters/FolderParameter.cpp" line="138"/>
        <source>Select a folder</source>
        <translation>Wybierz katalog</translation>
    </message>
</context>
<context>
    <name>GmicQt::GmicProcessor</name>
    <message>
        <location filename="../src/GmicProcessor.cpp" line="416"/>
        <source>Image #%1 returned by filter has %2 channels (should be at most 4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/GmicProcessor.cpp" line="452"/>
        <source>Image #%1 returned by filter has %2 channels
(should be at most 4)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GmicQt::HeadlessProcessor</name>
    <message>
        <location filename="../src/HeadlessProcessor.cpp" line="79"/>
        <source>At least a filter path or a filter command must be provided.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HeadlessProcessor.cpp" line="81"/>
        <source>Custom command (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HeadlessProcessor.cpp" line="89"/>
        <source>Cannot find filter matching path %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HeadlessProcessor.cpp" line="96"/>
        <source>Error parsing filter parameters definition for filter:

%1

Cannot retrieve default parameters.

%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HeadlessProcessor.cpp" line="114"/>
        <source>Error parsing supplied command: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HeadlessProcessor.cpp" line="117"/>
        <source>Supplied command (%1) does not match path (%2), (should be %3).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/HeadlessProcessor.cpp" line="229"/>
        <source>Filter execution failed, but with no error message.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GmicQt::InOutPanel</name>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="62"/>
        <source>Input layers</source>
        <translation>Wartstwy wejściowe</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="68"/>
        <source>None</source>
        <translation>Brak</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="69"/>
        <source>Active (default)</source>
        <translation>Aktywna (domyślnie)</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="70"/>
        <source>All</source>
        <translation>Wszystkie</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="71"/>
        <source>Active and below</source>
        <translation>Aktywna i poniżej</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="72"/>
        <source>Active and above</source>
        <translation>Aktywna i powyżej</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="73"/>
        <source>All visible</source>
        <translation>Wszystkie widoczne</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="74"/>
        <source>All invisible</source>
        <translation>Wszystkie niewidoczne</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="85"/>
        <source>Output mode</source>
        <translation>Tryb wyjścia</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="91"/>
        <source>In place (default)</source>
        <translation>Na miejscu (domyślnie)</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="92"/>
        <source>New layer(s)</source>
        <translation>Nowa(e) warstwa(y)</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="93"/>
        <source>New active layer(s)</source>
        <translation>Nowa(e) aktywna(e) warstwa(y)</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="94"/>
        <source>New image</source>
        <translation>Nowy obraz</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="205"/>
        <source>Input / Output</source>
        <translation>Wejście/Wyjście</translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="207"/>
        <source>Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Widgets/InOutPanel.cpp" line="209"/>
        <source>Output</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GmicQt::LanguageSelectionWidget</name>
    <message>
        <location filename="../src/Widgets/LanguageSelectionWidget.cpp" line="53"/>
        <source>System default (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Widgets/LanguageSelectionWidget.cpp" line="62"/>
        <source>Translations are very likely to be incomplete.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GmicQt::MainWindow</name>
    <message>
        <location filename="../src/MainWindow.cpp" line="108"/>
        <source>Add fave</source>
        <translation>Dodaj do ulubionych</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="110"/>
        <source>Reset parameters to default values</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="113"/>
        <source>Randomize parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="119"/>
        <source>Copy G&apos;MIC command to clipboard</source>
        <translation>Skopiuj polecenie G&apos;MIC do schowka</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="126"/>
        <source>Rename fave</source>
        <translation>Zmiana nazwy ulubionego</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="128"/>
        <source>Remove fave</source>
        <translation>Usuń z ulubionych</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="132"/>
        <source>Expand/Collapse all</source>
        <translation>Rozwiń/zwiń wszystko</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="134"/>
        <source>G&apos;MIC (https://gmic.eu)&lt;br/&gt;GREYC (https://www.greyc.fr)&lt;br/&gt;CNRS (https://www.cnrs.fr)&lt;br/&gt;Normandy University (https://www.unicaen.fr)&lt;br/&gt;Ensicaen (https://www.ensicaen.fr)</source>
        <translation>G&apos;MIC (https://gmic.eu)&lt;br/&gt;GREYC (https://www.greyc.fr)&lt;br/&gt;CNRS (https://www.cnrs.fr)&lt;br/&gt;Uniwerstytet Normandii (https://www.unicaen.fr)&lt;br/&gt;Ensicaen (https://www.ensicaen.fr)</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="141"/>
        <source>Selection mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="180"/>
        <source>Update filters</source>
        <translation>Uaktualnienie filtrów</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="232"/>
        <source>Manage visible tags
(Right-click on a fave or a filter to set/remove tags)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="238"/>
        <source>Force &amp;quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="242"/>
        <source>Full</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="243"/>
        <source>Forward Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="244"/>
        <source>Forward Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="245"/>
        <source>Backward Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="246"/>
        <source>Backward Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="247"/>
        <source>Duplicate Top</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="248"/>
        <source>Duplicate Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="249"/>
        <source>Duplicate Bottom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="250"/>
        <source>Duplicate Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="251"/>
        <source>Duplicate Horizontal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="252"/>
        <source>Duplicate Vertical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="253"/>
        <source>Checkered</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="254"/>
        <source>Checkered Inverse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="376"/>
        <source>Update completed</source>
        <translation>Aktualizacja ukończona</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="376"/>
        <location filename="../src/MainWindow.cpp" line="378"/>
        <location filename="../src/MainWindow.cpp" line="509"/>
        <source>Filter definitions have been updated.</source>
        <translation>Filtry zaktualizowane.</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="381"/>
        <source>No download was needed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="427"/>
        <source>Plugin was called with a filter path with no matching filter:

Path: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="435"/>
        <location filename="../src/MainWindow.cpp" line="462"/>
        <source>Error parsing filter parameters definition for filter:

%1

Cannot retrieve default parameters.

%2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="448"/>
        <source>Plugin was called with a command that cannot be recognized as a filter:

Command: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="927"/>
        <source>[Elapsed time: %1]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="443"/>
        <source>Plugin was called with a command that cannot be parsed:

%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="452"/>
        <source>Plugin was called with a command that does not match the provided path:

Path: %1
Command: %2
Command found for this path : %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="505"/>
        <source>Filters update could not be achieved</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="646"/>
        <source>The update could not be achieved&lt;br&gt;because of the following errors:&lt;br&gt;</source>
        <translation>Aktualizacja nie powiodła się&lt;br/&gt;z następujących powodów:&lt;br/&gt;</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="652"/>
        <source>Update error</source>
        <translation>Błąd aktualizacji</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="859"/>
        <source>Error</source>
        <translation>Wystąpił błąd</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="1478"/>
        <source>Waiting for cancelled jobs...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="1332"/>
        <source>Import faves</source>
        <translation>Importuj ulubione</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="1332"/>
        <source>Do you want to import faves from file below?&lt;br/&gt;%1</source>
        <translation>Czy chcesz importować ulubione z pliku poniżej?&lt;br/&gt;%1</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="1335"/>
        <source>Don&apos;t ask again</source>
        <translation>Nie pytaj ponownie</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="1454"/>
        <source>Confirmation</source>
        <translation>Potwierdż</translation>
    </message>
    <message>
        <location filename="../src/MainWindow.cpp" line="1454"/>
        <source>A gmic command is running.&lt;br&gt;Do you really want to close the plugin?</source>
        <translation>Polecenie gmic jest uruchomione.&lt;br&gt;Czy naprawdę chcesz zamknąć wtyczkę?</translation>
    </message>
</context>
<context>
    <name>GmicQt::MultilineTextParameterWidget</name>
    <message>
        <location filename="../src/FilterParameters/MultilineTextParameterWidget.cpp" line="41"/>
        <source>Ctrl+Return</source>
        <translation>Ctrl+Enter</translation>
    </message>
</context>
<context>
    <name>GmicQt::ProgressInfoWidget</name>
    <message>
        <location filename="../src/Widgets/ProgressInfoWidget.cpp" line="50"/>
        <source>G&apos;MIC-Qt Plug-in progression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Widgets/ProgressInfoWidget.cpp" line="53"/>
        <source>Abort</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../src/Widgets/ProgressInfoWidget.cpp" line="126"/>
        <source>[Processing 88:00:00.888 | 888.9 GiB]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Widgets/ProgressInfoWidget.cpp" line="128"/>
        <source>[Processing 88:00:00.888]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Widgets/ProgressInfoWidget.cpp" line="160"/>
        <source>Updating filters...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Widgets/ProgressInfoWidget.cpp" line="213"/>
        <location filename="../src/Widgets/ProgressInfoWidget.cpp" line="221"/>
        <source>[Processing %1 | %2]</source>
        <translation>[Przetwarzanie %1 | %2]</translation>
    </message>
    <message>
        <location filename="../src/Widgets/ProgressInfoWidget.cpp" line="223"/>
        <source>[Processing %1]</source>
        <translation>[Przetwarzanie %1]</translation>
    </message>
</context>
<context>
    <name>GmicQt::ProgressInfoWindow</name>
    <message>
        <location filename="../src/Widgets/ProgressInfoWindow.cpp" line="49"/>
        <source>G&apos;MIC-Qt Plug-in progression</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Widgets/ProgressInfoWindow.cpp" line="141"/>
        <source>%1 seconds</source>
        <translation>%1 sekund</translation>
    </message>
    <message>
        <location filename="../src/Widgets/ProgressInfoWindow.cpp" line="151"/>
        <source>[Processing %1 | %2]</source>
        <translation>[Przetwarzanie %1 | %2]</translation>
    </message>
    <message>
        <location filename="../src/Widgets/ProgressInfoWindow.cpp" line="153"/>
        <source>[Processing %1]</source>
        <translation>[Przetwarzanie %1]</translation>
    </message>
</context>
<context>
    <name>GmicQt::SearchFieldWidget</name>
    <message>
        <location filename="../src/Widgets/SearchFieldWidget.cpp" line="80"/>
        <source>Search</source>
        <translation>Wyszukiwanie</translation>
    </message>
    <message>
        <location filename="../src/Widgets/SearchFieldWidget.cpp" line="81"/>
        <source>Search in filters list (%1)</source>
        <translation>Szukaj w liście filtrów (%1)</translation>
    </message>
</context>
<context>
    <name>GmicQt::SourcesWidget</name>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="58"/>
        <source>Move source up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="60"/>
        <source>Move source down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="62"/>
        <source>Add local file (dialog)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="64"/>
        <source>Reset filter sources</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="80"/>
        <source>Macros: $HOME %USERPROFILE% $VERSION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="102"/>
        <source>Environment variables (e.g. %USERPROFILE% or %HOMEDIR%) are substituted in sources.
VERSION is also a predefined variable that stands for the G&apos;MIC version number (currently %1).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="82"/>
        <source>Macros: $HOME $VERSION</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="53"/>
        <source>Remove source (Delete)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="85"/>
        <source>Disable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="86"/>
        <source>Enable without updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="87"/>
        <source>Enable with updates (recommended)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="106"/>
        <source>Environment variables (e.g. $HOME or ${HOME} for your home directory) are substituted in sources.
VERSION is also a predefined variable that stands for the G&apos;MIC version number (currently %1).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="111"/>
        <source>New source</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/SourcesWidget.cpp" line="192"/>
        <source>Select a file</source>
        <translation type="unfinished">Wybierz plik</translation>
    </message>
</context>
<context>
    <name>GmicQt::Updater</name>
    <message>
        <location filename="../src/Updater.cpp" line="137"/>
        <source>Error downloading %1 (empty file?)</source>
        <translation>Błąd pobierania %1 (Pusty plik?)</translation>
    </message>
    <message>
        <location filename="../src/Updater.cpp" line="146"/>
        <source>Could not read/decompress %1</source>
        <translation>Błąd odczytu/dekompresji %1</translation>
    </message>
    <message>
        <location filename="../src/Updater.cpp" line="151"/>
        <source>Error writing file %1</source>
        <translation>Błąd zapisu pliku %1</translation>
    </message>
    <message>
        <location filename="../src/Updater.cpp" line="168"/>
        <source>Error downloading %1&lt;br/&gt;Error %2: %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Updater.cpp" line="204"/>
        <source>Download timeout: %1</source>
        <translation>Limit czasu pobierania: %1</translation>
    </message>
</context>
<context>
    <name>GmicQt::VisibleTagSelector</name>
    <message>
        <location filename="../src/Widgets/VisibleTagSelector.cpp" line="55"/>
        <source>Show All Filters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Widgets/VisibleTagSelector.cpp" line="59"/>
        <source>Show %1 Tags</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GmicQt::ZoomLevelSelector</name>
    <message>
        <location filename="../src/Widgets/ZoomLevelSelector.cpp" line="54"/>
        <source>Zoom in</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Widgets/ZoomLevelSelector.cpp" line="55"/>
        <source>Zoom out</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Widgets/ZoomLevelSelector.cpp" line="56"/>
        <source>Reset zoom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Widgets/ZoomLevelSelector.cpp" line="155"/>
        <source>Warning: Preview may be inaccurate (zoom factor has been modified)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>HeadlessProgressDialog</name>
    <message>
        <location filename="../ui/headlessprogressdialog.ui" line="14"/>
        <source>Dialog</source>
        <translation>Okno dialogowe</translation>
    </message>
    <message>
        <location filename="../ui/headlessprogressdialog.ui" line="68"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
</context>
<context>
    <name>InOutPanel</name>
    <message>
        <location filename="../ui/inoutpanel.ui" line="40"/>
        <source>Input / Output</source>
        <translation>Wejście/Wyjście</translation>
    </message>
    <message>
        <location filename="../ui/inoutpanel.ui" line="47"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/inoutpanel.ui" line="92"/>
        <source>Input layers</source>
        <translation>Wartstwy wejściowe</translation>
    </message>
    <message>
        <location filename="../ui/inoutpanel.ui" line="115"/>
        <source>Output mode</source>
        <translation>Tryb wyjścia</translation>
    </message>
</context>
<context>
    <name>JpegQualityDialog</name>
    <message>
        <location filename="../src/Host/None/jpegqualitydialog.ui" line="14"/>
        <source>Dialog</source>
        <translation type="unfinished">Okno dialogowe</translation>
    </message>
    <message>
        <location filename="../src/Host/None/jpegqualitydialog.ui" line="20"/>
        <location filename="../src/Host/None/JpegQualityDialog.cpp" line="13"/>
        <source>JPEG Quality</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Host/None/jpegqualitydialog.ui" line="28"/>
        <source>0</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Host/None/jpegqualitydialog.ui" line="42"/>
        <source>100</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Host/None/jpegqualitydialog.ui" line="60"/>
        <source>Always use this quality for this execution of G&apos;MIC-Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Host/None/jpegqualitydialog.ui" line="85"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished">&amp;Anuluj</translation>
    </message>
    <message>
        <location filename="../src/Host/None/jpegqualitydialog.ui" line="92"/>
        <source>&amp;Ok</source>
        <translation type="unfinished">&amp;Ok</translation>
    </message>
</context>
<context>
    <name>LanguageSelectionWidget</name>
    <message>
        <location filename="../ui/languageselectionwidget.ui" line="14"/>
        <source>Form</source>
        <translation>GMIC</translation>
    </message>
    <message>
        <location filename="../ui/languageselectionwidget.ui" line="35"/>
        <source>&lt;i&gt;(Restart needed)&lt;/i&gt;</source>
        <translation>&lt;i&gt;(Wymaga zrestartowania)&lt;/i&gt;</translation>
    </message>
    <message>
        <location filename="../ui/languageselectionwidget.ui" line="48"/>
        <source>Translate filters (WIP)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../ui/mainwindow.ui" line="18"/>
        <source>Form</source>
        <translation>GMIC</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="176"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Download filter definitions from remote sources&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Uaktualnienie filtrów przez internet&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="179"/>
        <source>Internet</source>
        <translation>Internet</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="418"/>
        <source>Preview type (Ctrl+Shift+P)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="509"/>
        <source>&amp;Settings...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="525"/>
        <location filename="../ui/mainwindow.ui" line="532"/>
        <source>TextLabel</source>
        <translation type="unfinished">TextLabel</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="248"/>
        <location filename="../ui/mainwindow.ui" line="255"/>
        <location filename="../ui/mainwindow.ui" line="262"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation type="unfinished">MainWindow</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="408"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable/disable preview&lt;br/&gt;(Ctrl+P)&lt;br/&gt;(right click on preview image for instant swapping)&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="411"/>
        <source>Preview</source>
        <translation>Podgląd</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="558"/>
        <source>&amp;Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="571"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Anuluj</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="545"/>
        <source>&amp;Fullscreen</source>
        <translation>&amp;Pełny ekran</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="584"/>
        <source>&amp;Apply</source>
        <translation>&amp;Zastosuj</translation>
    </message>
    <message>
        <location filename="../ui/mainwindow.ui" line="597"/>
        <source>&amp;OK</source>
        <translation>&amp;Ok</translation>
    </message>
</context>
<context>
    <name>MultilineTextParameterWidget</name>
    <message>
        <location filename="../ui/multilinetextparameterwidget.ui" line="14"/>
        <source>Form</source>
        <translation>GMIC</translation>
    </message>
    <message>
        <location filename="../ui/multilinetextparameterwidget.ui" line="29"/>
        <source>Update</source>
        <translation>Uaktualnij</translation>
    </message>
</context>
<context>
    <name>ProgressInfoWidget</name>
    <message>
        <location filename="../ui/progressinfowidget.ui" line="14"/>
        <source>Form</source>
        <translation>GMIC</translation>
    </message>
    <message>
        <location filename="../ui/progressinfowidget.ui" line="48"/>
        <source>Abort</source>
        <translation>Anuluj</translation>
    </message>
    <message>
        <location filename="../ui/progressinfowidget.ui" line="55"/>
        <source>TextLabel</source>
        <translation>TextLabel</translation>
    </message>
</context>
<context>
    <name>ProgressInfoWindow</name>
    <message>
        <location filename="../ui/progressinfowindow.ui" line="14"/>
        <source>MainWindow</source>
        <translation>MainWindow</translation>
    </message>
    <message>
        <location filename="../ui/progressinfowindow.ui" line="30"/>
        <location filename="../ui/progressinfowindow.ui" line="50"/>
        <source>TextLabel</source>
        <translation>TextLabel</translation>
    </message>
    <message>
        <location filename="../ui/progressinfowindow.ui" line="72"/>
        <source>Cancel</source>
        <translation>Anuluj</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../src/Host/None/host_none.cpp" line="76"/>
        <source>Select an image to open...</source>
        <translation>Wybierz obraz...</translation>
    </message>
    <message>
        <location filename="../src/Host/None/host_none.cpp" line="84"/>
        <source>Error</source>
        <translation>Wystąpił błąd</translation>
    </message>
    <message>
        <location filename="../src/Host/None/host_none.cpp" line="84"/>
        <source>Could not open file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Host/None/host_none.cpp" line="88"/>
        <source>Default image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterSelector/FiltersView/FiltersView.cpp" line="81"/>
        <source>Visible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/FilterSelector/FiltersPresenter.cpp" line="107"/>
        <source>Available filters (%1)</source>
        <translation>Dostępne filtry (%1)</translation>
    </message>
    <message>
        <location filename="../src/Tags.cpp" line="151"/>
        <source>%1 Tag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tags.cpp" line="157"/>
        <source>None</source>
        <translation type="unfinished">Brak</translation>
    </message>
    <message>
        <location filename="../src/Tags.cpp" line="158"/>
        <source>Red</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tags.cpp" line="159"/>
        <source>Green</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tags.cpp" line="160"/>
        <source>Blue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tags.cpp" line="161"/>
        <source>Cyan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tags.cpp" line="162"/>
        <source>Magenta</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Tags.cpp" line="163"/>
        <source>Yellow</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/LanguageSettings.cpp" line="127"/>
        <source>Could not install translator for file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/LanguageSettings.cpp" line="130"/>
        <source>Could not load translation file %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Misc.cpp" line="337"/>
        <source>List %1 cannot be merged considering these runs: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Misc.cpp" line="432"/>
        <source>%1 GiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Misc.cpp" line="434"/>
        <source>%1 MiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Misc.cpp" line="436"/>
        <source>%1 KiB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Misc.cpp" line="438"/>
        <source>%1 B</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SearchFieldWidget</name>
    <message>
        <location filename="../ui/SearchFieldWidget.ui" line="20"/>
        <source>Frame</source>
        <translation>Ramka</translation>
    </message>
</context>
<context>
    <name>SourcesWidget</name>
    <message>
        <location filename="../ui/sourceswidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished">GMIC</translation>
    </message>
    <message>
        <location filename="../ui/sourceswidget.ui" line="136"/>
        <source>Official filters:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/sourceswidget.ui" line="22"/>
        <source>File / URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/sourceswidget.ui" line="32"/>
        <source>Add new</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/sourceswidget.ui" line="39"/>
        <location filename="../ui/sourceswidget.ui" line="55"/>
        <location filename="../ui/sourceswidget.ui" line="62"/>
        <location filename="../ui/sourceswidget.ui" line="85"/>
        <location filename="../ui/sourceswidget.ui" line="92"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../ui/sourceswidget.ui" line="118"/>
        <source>Macros: $HOME $VERSION</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ZoomLevelSelector</name>
    <message>
        <location filename="../ui/zoomlevelselector.ui" line="20"/>
        <source>Form</source>
        <translation>GMIC</translation>
    </message>
</context>
<context>
    <name>gmic_qt_standalone::ImageDialog</name>
    <message>
        <location filename="../src/Host/None/ImageDialog.cpp" line="73"/>
        <source>G&apos;MIC-Qt filter output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Host/None/ImageDialog.cpp" line="84"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Host/None/ImageDialog.cpp" line="87"/>
        <source>Save as...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Host/None/ImageDialog.cpp" line="122"/>
        <source>%1 file (*.%2 *.%3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/Host/None/ImageDialog.cpp" line="148"/>
        <source>Save image as...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>gmic_qt_standalone::ImageView</name>
    <message>
        <location filename="../src/Host/None/ImageDialog.cpp" line="65"/>
        <source>Error</source>
        <translation type="unfinished">Wystąpił błąd</translation>
    </message>
    <message>
        <location filename="../src/Host/None/ImageDialog.cpp" line="65"/>
        <source>Could not write image file %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
